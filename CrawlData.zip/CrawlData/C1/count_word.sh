cat /c/workspace/CrawlData/c1/contentText/* | tr -s [:punct:] ' '| tr -s ' ' '\n' | awk '{print tolower($0)}'| sort | uniq -c | awk '{print $1" "$2}'| sort -nr > output.txt
#awk '
#    BEGIN {OFS=","; print "Word Frequency", "Word"}
#    {print $1, $2}
#' raw_input3 > Output3.xls